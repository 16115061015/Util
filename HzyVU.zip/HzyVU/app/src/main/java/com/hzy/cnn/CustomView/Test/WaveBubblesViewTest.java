package com.hzy.cnn.CustomView.Test;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.hzy.cnn.CustomView.R;

/**
 * Author: huzeyu
 * Date: 2019/11/28
 * Description:
 */
public class WaveBubblesViewTest extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wave_bubbles_view_layout);
        //WaveBubblesView 使用实例

    }
}