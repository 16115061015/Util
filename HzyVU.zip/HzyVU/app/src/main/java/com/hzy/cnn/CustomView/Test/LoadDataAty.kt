package com.hzy.cnn.CustomView.Test

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.bumptech.glide.load.model.ModelLoader
import com.hzy.cnn.CustomView.R
import com.hzy.cnn.CustomView.Ui.adapter.LoadDataAdapter
import com.hzy.cnn.CustomView.contract.DataEnrty
import kotlinx.android.synthetic.main.aty_loaddata.*

/**
 * User: hzy
 * Date: 2020/3/29
 * Time: 11:57 PM
 * Description:
 */
class LoadDataAty : AppCompatActivity() {
    private lateinit var adapter:LoadDataAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.aty_loaddata)
        initView()
    }

    private fun initView() {
        adapter = LoadDataAdapter()
        recyclerView.adapter = adapter
        var datas = ArrayList<DataEnrty>()
        datas.add(DataEnrty(1,"1"))
        datas.add(DataEnrty(2,"2"))
        datas.add(DataEnrty(1,"3"))
        adapter.setNewData(datas)
    }
}