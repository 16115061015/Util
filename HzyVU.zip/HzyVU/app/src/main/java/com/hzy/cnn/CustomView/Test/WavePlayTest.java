package com.hzy.cnn.CustomView.Test;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.hzy.cnn.CustomView.R;

/**
 * Created by joel.
 * Date: 2019/5/17
 * Time: 20:04
 * Description:
 */
public class WavePlayTest extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.waveplay_layout);
    }
}
