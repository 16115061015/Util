package com.hzy.cnn.CustomView.contract

/**
 * User: hzy
 * Date: 2020/3/30
 * Time: 12:19 PM
 * Description:
 */

class DataEnrty (val type:Int = 0,val data:String = ""){

}