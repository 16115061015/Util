package com.hzy.cnn.CustomView.contract

import android.view.View
import com.chad.library.adapter.base.BaseViewHolder

/**
 * User: hzy
 * Date: 2020/3/30
 * Time: 12:20 PM
 * Description:
 */
class VH(view: View) :BaseViewHolder(view){

}